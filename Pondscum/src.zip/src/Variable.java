
public class Variable {
	private long total;
	private int loc_x, loc_y;

	public Variable(int x, int y) {
		total = 0;
		loc_x = x;
		loc_y = y;
	}

	public void setTotal(long s_mat) {
		total += s_mat;
	}
	
	public long getTotal() {
		return total;
	}
	
	public int getLoc_x() {
		return loc_x;
	}
	
	public int getLoc_y() {
		return loc_y;
	}
	
	public String toString() {
		return "(" + loc_x + "," + loc_y + ") Total = " + total;
		
	}
}
